2017/10/17:
> improvement

	1 add contrib/hiredis

2017/10/12:
> bug fix

	1 use atomic    

2017/09/14:
> improvement

    1 与C++11分支v1.0.9保持同步。吐槽一下，既然是C++11分支，chenshuo还是用了大量的boost。

2016/10/16:
> improvement

    1 更新代码，与master分支v1.0.8保持同步。

2015/06/07:
> improvement

    1 已经把muduo/net下各个子目录的boost剔除干净，工作暂时告完。待以后有机缘再完成muduo/examples下面的相关工作。
    
2015/05/27:
> improvement

	 1 完成了muduo/base/tests/和muduo/net/tests下面的所有的unittest和zlib相关的测试修改工作。
	 
> todo list

	1 完成muduo/net/下http这类各个子包的测试工作;

2015/05/20:
> todo list

	1 把boost unit test修改为gtest
		 